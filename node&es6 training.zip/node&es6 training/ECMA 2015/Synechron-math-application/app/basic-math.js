console.log("Sart of basic math module")
import SyneSquare from "./advance-math"
function add(num1, num2) {
    return num1 + num2;
}

function sub(num1, num2) {
    return num1 - num2;
}

var mul = function(num1, num2) {
    return num1 * num2;
}

function div(num1, num2) {
    return num1 / num2;
}

console.log(SyneSquare(23))
console.log("End of basic math module");

export {add, sub, mul}