console.log('start of basic math module')
//import {add, sub, mul} from './basic-math';
import * as math from './basic-math';

console.log(math.add(12,12))
console.log(math.sub(12,12))
console.log(math.mul(12,12))
