console.log("start o advanced math module")
export default function square(num) {
    return num * num;
}

console.log("End of advanced math module")