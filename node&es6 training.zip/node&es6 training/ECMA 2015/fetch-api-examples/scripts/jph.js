$(() => {
    let tableBody = $('#postsTableBody');

    fetch("https://jsonplaceholder.typicode.com/users").then(
        response => response.json(),
        reason => Promise.reject(reason)
    ).then(
        posts => {
            for (const item of posts) {
                var row = `
                    <tr>
                        <td>${item.name}</td>
                        <td>${item.email}</td>
                        <td>${item.address.city}</td>
                        <td>${item.phone}</td>
                        <td>${item.website}</td>
                        <td>${item.company.name}</td>
                    </tr>`;
                    tableBody.append(row);
            }
        }
    )
});