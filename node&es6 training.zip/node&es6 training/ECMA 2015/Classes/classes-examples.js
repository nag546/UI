class Person {
    
    constructor(socialId, name, city) {
        this._socialId = socialId;
        this._name = name;
        this._city = city;
    }
     
    get socialId() {
        return this._socialId
    }

    set socialId(value) {
        this._socialId = value;
    }

    get name() {
        return this._name
    }

    set name(value) {
        this._name = value;
    }

    get city() {
        return this._city
    }

    set city(value) {
        this._city = value;
    }

    getPersoninfor() {
        return `contact name is ${this.name} who live in ciy ${this.city}`;

    }


}

function extraPerson() {
    this.PersonName = '';
}

//Person.prototype.log

console.log(typeof Person);

let ExtraPerson = new extraPerson();


console.log('test');


// Is-A relationShip
class Customer extends Person {
    constructor(customerId) {
        super();
        this._customerId = customerId
    }
    get customerId() {
        return this._customerId;
    }

    set customerId(value) {
        this._customerId = value;

    }

    static getJoiningDateTime() {
        return new Date();
    }
}

let person = new Customer(534545)
person.socialId = 123;
person.name = 'linga';
person.city = 'GNT';
Customer.getJoiningDateTime();
console.log(person.getPersoninfor());

