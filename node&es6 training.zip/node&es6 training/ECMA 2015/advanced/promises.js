function getTodaysTemp() {
    setTimeout(() => {
        console.log(`Todays number is 26`);
    }, 3000);
}

console.log("calling weather report");
//console.log(getTodaysTemp());
console.log('reecived weather temp.');

const offices=["Bng", "Chn", "Hyd", "Pun", "Mum"];

function conferenceSchedule() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {  // Call ajax
            if(offices.length > 4) {
                resolve(offices);
            } else {
                reject("Cities are less to schedule the conference!");
            }
        }, 2000);
    });
}

let sendEmail = conferenceSchedule();
sendEmail.then(
    cities => cities,   //console.log(cities)
    reason => Promise.reject(reason)
).then(
    conferenceCities => {
        for(const city of conferenceCities) {
            if(city == 'Mum') {
                console.log('Conference is cancelled');
            } else {
                console.log('Your conference has been scheduled in cities')
            }
        }
    },
    reason => console.log(reason)
)



let task1 = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve("task1 is completed")
    }, 300);
})
let task2 = new Promise((resolve, reject) => {
    setTimeout(() => {
        //resolve("task2 is completed")
        reject("tasks2 is failed")
    }, 400);

})
let task3 = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve("task3 is completed")
    }, 500);

})
    // setTimeout(() => {
    //     resolve("task4 is completed")
    // }, 300);


Promise.all([task1,task2, task3]).then(
    tasks => console.log(tasks),
    reasons => console.log(reasons)
);

Promise.race([task1,task2, task3]).then(
    tasks => console.log(tasks),
    reasons => console.log(reasons)
);