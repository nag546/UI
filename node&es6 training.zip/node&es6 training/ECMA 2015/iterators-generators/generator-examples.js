function* customerNumberGeneaor(initialCustomerId) {

    while (initialCustomerId <= 501) {
        yield initialCustomerId +=5;
    }

    
    // yield 1000;
    // yield 1001;
    // yield 1002;

}

let nextCustomer = customerNumberGeneaor();
//console.log(nextCustomer.next())

for (const item of customerNumberGeneaor(5)) {
    console.log(item)       
}

Promise.ra