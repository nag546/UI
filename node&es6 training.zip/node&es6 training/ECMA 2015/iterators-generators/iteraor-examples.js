const CITIES = ['Bng', 'Chn', 'Del', 'Hyd'];
const obj = {};
for (const item of CITIES) {
    console.log(item)
}

//console.log(typeof CITIES[Symbol.iterator]);
console.log(typeof CITIES[Symbol.iterator]())

let offcities = CITIES[Symbol.iterator]()
offcities.next();

const AutoTokenenerator = {
    [Symbol.iterator]() {
        let intializeToken = 1;
        return {
            next() {
                let value = intializeToken > 500 ? undefined : intializeToken++;
                let done = !value;
                return {
                    value,
                    done
                }
            }
        }
    }
}

for (const token of AutoTokenenerator) {
    console.log(token)
}