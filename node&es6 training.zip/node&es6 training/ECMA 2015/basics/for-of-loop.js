const offices = ['Bang', 'Chn', 'Hyd', 'Pun'];

offices.forEach(element => {
    if(element == 'Hyd') {
        //continue;    error
    }
}) 

//  For-of loop finds start and end of the values [Iterartors]
for(const i of offices) {
    console.log(i); 
    if(i == 'Hyd') {
        break;
    }
}

// for (const key in object) {
//     if (object.hasOwnProperty(key)) {
//         const element = object[key];
        
//     }
// }