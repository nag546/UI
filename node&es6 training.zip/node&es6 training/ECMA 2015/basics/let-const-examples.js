{
    let  x = 100;
}
//console.log(x);

if(true) {
    let  y = 10;
}
//console.log(y);

for(var i=0; i<5; i++) {
    //logic goes here
}
console.log(i);


//hoisting
console.log(companyName)
var companyName = 'synechron';
companyName = 'microsoft';
console.log(companyName);


const PI = 3.14;    
const offices =['HYD', 'BNG'];
offices[1] = 'PUN';
console.log(offices);

const new_offices = offices;
console.log(new_offices);

