const Mobiles = ["mobile1", "mobile2", "mobile3"];

let [m1,m2,m3] = Mobiles;
let [mobi1, ,mobi3] = Mobiles;
let [mobile1, ...allMobiles] = Mobiles;

console.log(m1)

//destructuring objects
const order = {
    orderId: 789,
    orderDate: new Date()
}

let {orderId, orderDate} = order;
console.log(orderDate);

let oid, odate;
({orderId:oid, orderDate:odate} = order);
console.log(oid);

let companyName = 'Synechron';
let [l1,l2,l3] = companyName;
console.log(l3)