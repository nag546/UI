
const GST_PERC = {
    IT: 18,
    FOOD: 5

}

function gstPercentageCal() {
    return 15;
}

function salesNetPkrofit(cogs, expense = 120000, actualSales, gstPercentage = GST_PERC.IT) {
    let gstAmount = actualSales * gstPercentage / 100;
    return actualSales - (cogs + expense + gstAmount)
}

console.log(salesNetPkrofit(12000, undefined, 1500000));    //undefined is mandatory for default values
console.log(salesNetPkrofit(12000,  null, 1500000));


//  ? is default parameter
