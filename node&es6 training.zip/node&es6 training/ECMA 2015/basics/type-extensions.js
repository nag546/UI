// Number Extensions
let num1 = NaN;
let num2 = "NaN";

if(Number.isNaN(num2)) {
    console.log('not a number')
} else {
    console.log('not a nation')
}

console.log(Number.isInteger(100))
console.log(Number.isInteger(-100))
console.log(Number.isInteger(NaN));


//Array Extension 
const arrays = new Array(10, 20);
const arrays1 = new Array.of(10);
const arrays2 = new Array(10);

console.log(arrays.length); //2
console.log(arrays2.length);    //10
console.log(arrays1.length);    //1
