function printSynechronCities() {
    console.log(arguments.length);
    for (const key in arguments) {
        if (arguments.hasOwnProperty(key)) {
            //const element = object[key];
            console.log(key)
        }
    }

    if(arguments.length > 0) {
        for (let index = 0; index < arguments.length; index++) {
            const element = arguments[index];
            
        }
    }


}

const VISITED_OFFICES = ['Bang', 'Hyd', 'Pune', 'Abu bhabi']
function printSynechronCities(...cities) {  //REST operator
    //console.log(cities);
    for (const iterator of cities) {
        console.log(iterator)
    }
}

printSynechronCities(...VISITED_OFFICES)   //SPREAD opearaor
printSynechronCities('Bang', 'Hyd', 'Pune')
printSynechronCities('Bang', 'Hyd', 'Pune', 'Chn')
printSynechronCities('Bang', 'Hyd', 'Pune', 'Abu bhabi')

//REST is a parameter
//SPREAD is a operaor

const PizzaOder = {
    orderId: 123,
    customerId: 456,
    orderDateTime: new Date(),
    status: 'Order de;livered successfully'
}
console.log(PizzaOder);

const PizzaInOven = {
    ...PizzaOder,
    status: 'ur pizza is getting back to oven'
}
console.log(PizzaInOven);

const PizzaOutDelivery = {
    ...PizzaInOven,
    status: 'Pizza out of delivery'
}
console.log(PizzaOutDelivery);
