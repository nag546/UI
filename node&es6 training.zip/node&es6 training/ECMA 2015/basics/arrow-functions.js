const Person = {
    socialId:12345,
    contactName:'Linga',
    city:'Hyderabad',
    /**getCustomerInfor: function() {
        // var self = this;
        // setTimeout(function() {
        //     console.log(`social id is ${self.socialId}, contact name is ${self.contactName} who lives in ${self.city}`);
        // },2000);

        //var self = this;
        setTimeout(function() {
            console.log(`social id is ${this.socialId}, contact name is ${this.contactName} who lives in ${this.city}`);
        }.bind(this), 2000);

        // return `social id is ${this.socialId}, contact name is ${this.contactName} who lives in ${this.city}`;
    } **/
    getCustomerInforWithArrow: function() {
        setTimeout(() => {
            console.log(`social id is ${this.socialId}, contact name is ${this.contactName} who lives in ${this.city}`);
        }, 2000);
    },
    sampleGetfuc() {
        console.log('test')
    }
}

//Person.getCustomerInfor();
Person.getCustomerInforWithArrow();
Person.sampleGetfuc();

//ex1 Simple arrow functions with out paramerts
let msg1= () => console.log('Welcome to arrow functions');
msg1();

//ex2 one paramerter one line and one statement with in a body then no need to write () and return keyword
let square = num => num * num;
console.log(square(12));

//ex3 ore than one parameter and more than one line in body and if any return content then we need () and {} and depends on requirement need return keyword also
let sales = (cogs, expense, actualSales, gst = 18) => {
    let gstAmount = actualSales * gst / 100;
    //return actualSales - (cogs + expense + gstAmount);
    console.log(actualSales - (cogs + expense + gstAmount))
}

//console.log(sales(12000, 13000, 1500000));
sales(12000, 13000, 1500000)

