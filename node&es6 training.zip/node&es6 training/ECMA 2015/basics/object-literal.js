let cusId = 123, conName = 'linga', city='Hyd';

const Customer = {
    cusId,
    conName,
    city
}

console.log(Customer)