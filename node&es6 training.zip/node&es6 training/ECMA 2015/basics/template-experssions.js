var Customer = {
    customerId: 123,
    contactName: 'Linga',
    city:'HYD'
}

// Printing the object values 
console.log('Customer id is' + Customer.customerId + 'Name is' + Customer.contactName + 'Who lives in city' + Customer.city)

console.log("cusomer id is %s, name is %5", Customer.customerId, Customer.contactName)

function getCustomerName() {
    return "cusomer id is %s, name is %5", Customer.customerId, Customer.contactName;
}

// function getCustomerName() {
//     return "cusomer id is %s, name is %5", Customer.customerId, Customer.contactName;
// }

console.log(getCustomerName())  //Giving only contact name
console.log(`Coustomer id is ${Customer.customerId} name is ${Customer.contactName}`);

//  ${} is for function evaluation, objects and variables

try {

alert('abcd')
}

catch {
    console.log('test')
}