exports.add = function(num1, num2) {
    return num1+num2;
}

module.exports.mul = function(num1, num2) {
    return num1*num2;
}

