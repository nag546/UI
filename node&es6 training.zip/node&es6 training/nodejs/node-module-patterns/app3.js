const mySquare = require('./anonymous-function');

console.log(mySquare(5));

