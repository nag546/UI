console.log('start of the module')
module.exports = function(num) {
    return num * num;
}