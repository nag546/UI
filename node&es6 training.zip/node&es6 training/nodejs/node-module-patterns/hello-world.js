console.log('first node js example');
