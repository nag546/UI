//Imports and exports 
require("./example1");

console.log(displayCompanyname());
