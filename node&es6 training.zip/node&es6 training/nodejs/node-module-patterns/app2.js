const math = require("./example2");

