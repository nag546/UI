// Are we poluting the global scope? YES don't write this code in node module
displayCompanyname = function() {
    return "Synechron Technologies Pv. Ltd.!!!";
}


