const fs = require('fs');

console.log('start reading the file');

let contents = '';

fs.readFile("package.json", (err, data) => {
    if(err) {
        console.log('There was an error while reading the file.');
        console.log(err);
        return;
    }
    //contents = data.toString();
    
    fs.writeFile("package-copy.json", data.toString(), (err) => {
        if(err) {
            console.log('There was an error while writing the file.');
            console.log(err);
            return;
        }
        console.log('file write operation is successful');
    })

});


//const strdata = fs.readFileSync("package.json", "utf8");
//console.log(strdata)

console.log('end reading the file')