const fs = require('fs');

function readLocalFile() {
    return new Promise((resolve, reject) => {
        fs.readFile("package123.json", (err, data) => {
            if(err) {
                //console.log('There was an error while reading the file.');
                //console.log(err);
                reject(err);
                return;
            }
            if(data)
            resolve(data.toString());
        });
    });
}

function createAndWiteFileContents(contents) {
    return new Promise((resolve, reject) => {
        if(contents != undefined) {
        fs.writeFile("package-copy.json", contents, (err) => {
            if(err) {
                ///console.log('There was an error while writing the file.');
                //console.log(err);
                reject(err);
                return;
            }
            resolve('file write operation is successful');
        });
        }
        reject('faild to wie file')
    });
}

console.log('Start of read/write operations');
(async function() {
    let contents = await readLocalFile().catch(reason => console.log(reason));
    console.log(await createAndWiteFileContents(contents).catch(reason => console.log(reason)));
    /*if(contents != undefined) {
        console.log(await createAndWiteFileContents(contents).catch(reason => console.log(reason)));
    } else {
        console.log('file write opration is failed.')
    }*/
    
})();
console.log('End of read/write operations');