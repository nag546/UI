const express = require('express');
const jwt = require('jsonwebtoken');
const config = require('../config');

const employeeDal = require('../dal/employee-dal');

const employeeRoutes = express.Router();
employeeRoutes.use((request, response, next) => {
    let authToken = {
        token: request.body.token || request.query.token || request.headers["x-access-token"]
    };
    console.log(authToken.token)
    if(authToken.token) {
        jwt.verify(authToken.token, config.secet, (err, decoded) => {
            if(err) {
                response.json({
                    success: false,
                    message: 'we are unable to verify the token'
                });
            }
            next();
        })
    } else {
        response.json({
            success: false,
            message: "please send the token for authentication"
        })
    }
})

employeeRoutes.get('/', (request, response) => {
    employeeDal.getAllEemployees().then(
        events => response.json(events),
        reason => response.json(reason)
    )
});

employeeRoutes.post('/', (request, response) => {
    employeeDal.registerNewEmployee(request.body).then(
        event => response.json(event),
        reason => response.json(reason)
    )
});

employeeRoutes.get('/:id', (request, response) => {
    employeeDal.getEmployeeDetails(request.params.id).then(
        event => response.json(event),
        reason => response.json(reason)
    )
});


module.exports = employeeRoutes;