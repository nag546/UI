const express = require('express');
const securityDal = require('../dal/security-dal');

const securityRoutes = express.Router();

securityRoutes.post("/", (request, response) => {
    let userName = request.body.name;
    let  password = request.body.password;
    securityDal.checkCredentials(userName, password).then(
        authTokenObject => response.json(authTokenObject),
        reason => response.json(reason)
    );
});

module.exports = securityRoutes;
