const Employee = require('./person');

let e1 = new Employee('linga', 'HYD', 'linga@mail.com');
let e2 = new Employee('nageswararao', 'GNT', 'nageswararao@mail.com');

let employees = [e1, e2];

employees.forEach(employee => {
    employee.on('travelling', (name, city) => {
        console.log(`Employee ${name} city is ${city} from ${employee.city}`);
    })
})

let weatherOfIndia = 'Bad';
if(weatherOfIndia == 'Bad') {
    e1.off('travelling', () => console.log('bad weather condition'));
}


e1.emit('travelling', e1.name, 'Bng');
e1.emit('travelling', e1.name, 'Hyd');
e1.emit('travelling', e1.name, 'Mum');