const events = require('events');

class Person extends events.EventEmitter {
    constructor(name, city, email) {
        super();
        this.name = name;
        this.city = city;
        this.email = email;

    }
}

module.exports = Person;
