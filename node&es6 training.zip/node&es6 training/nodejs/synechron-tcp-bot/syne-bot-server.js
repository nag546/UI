const net = require('net');

const server = net.createServer();

server.on("connection", socket => {
    let remoteAddress = `${socket.remoteAddress} : ${socket.remotePort}`;
    console.log(`new connection from A client: ${remoteAddress}`);
    socket.on("data", data => {
        console.log(`client ${remoteAddress} sent the data is ${data.toString()}`);
        socket.write(`thanks fo the request ${data.toString()} is under process`);
    });

    socket.once("close", had_error => {
        if(had_error) {
            console.log(`somethinig went wrong while closing the connection of a client ${remoteAddress}`);
        }
        console.log(`connection is losedby ${remoteAddress}`)
    });

    socket.on("error", err => console.log(err));
})
server.listen(9090, () => console.log('Synechron TCP bot is listing on port : 9090'));
