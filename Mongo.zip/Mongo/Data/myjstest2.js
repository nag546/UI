for(i=0; i<100; i++){
   db.users2.insertOne(
     { "_id" : i, "username":"user"+i, "age":Math.floor(Math.random()*120), "created":new Date()}
  );
}