/*
user:  
  name, dob, interests, contact, address (city, state)
*/

db.users.insertOne(
    {
		name: "Kanakaraju",
		age: 43,
		marks: [80,50,60,70,90],
		hobbies: ["Reading", "Movies", "Chess"],
		contact: { phone: "1234567890", email: "kanakaraju@gmail.com", facebook: "kanaka.raju.10000" },
		address: {city: "Hyderabad", state: "Telangana"}
    }
)

db.users.insertMany([
	{
		name: "Harsha",
		age:29,
		marks: [85,55,65,75,95],
		hobbies: ["Sports", "Movies", "Cooking"],
		contact: { phone: "2345678765", email: "harsha@gmail.com", facebook: "harsha.raju.10000" },
		address: {city: "Hyderabad", state: "Telangana"}
	},
	{
		name: "Krishna",
		age: 55,
		marks: [75,65,66,78,105],
		hobbies: ["Cooking", "Movies", "Sports"],
		contact: { phone: "9876543210", email: "krishna@gmail.com", facebook: "krishna.10000" },
		address: {city: "Hyderabad", state: "Telangana"}
	},
	{
		name: "Amrita",
		age: 11,
		marks: [95,165,166,178,105],
		hobbies: ["Reading", "Movies", "Chess"],
		contact: {email: "amrita@gmail.com" },
		address: {city: "Bangalore", state: "Karnataka"}
	},
	{
		name: "Amar",
		age: 55,
		marks: [90,75,76,78,85],
		hobbies: ["Cooking", "Movies", "Sports"],
		contact: { phone: "9876543210", email: "amar@gmail.com", facebook: "krishna.10000" },
		address: {city: "Hyderabad", state: "Telangana"}
	},
	{
		name: "Radhika",
		age: 25,
		marks: [90,75,76,78,85],
		hobbies: ["Reading", "Movies", "Chess"],
		contact: {email: "radhika@gmail.com" },
		address: {city: "Bangalore", state: "Karnataka"}
	}
])

db.users.insert(
	{
		name: "Aditya",
		age:13,
		marks: [94,78,77,77,87],
		hobbies: ["Poetry", "Drawing", "Badminton"],
		contact: {email: "aditya@gmail.com" },
		address: {city: "Bangalore", state: "Karnataka"}
	}
)

db.users.insert(
    [{
		name: "Pranav",
		age:11,
		marks: [84,88,87,87,87],
		hobbies: ["Reading", "Movies", "Badminton"],
		contact: {email: "pranav@gmail.com" },
		address: {city: "Pune", state: "Maharashtra"}
	},
	{
		name: "Keerthana",
		age:11,
		marks: [94,98,87,73,66],
		hobbies: ["Reading", "Painting", "Badminton"],
		contact: {email: "pranav@gmail.com"},
		address: {city: "Pune", state: "Maharashtra"}
	},
	{
		name: "Komala",
		age: 37,
		marks: [94,72,57,57,67],
		hobbies: ["Reading", "Movies", "Chess"],
		contact: {email: "komala@gmail.com", phone: "9246656734"},
		address: {city: "Pune", state: "Maharashtra"}
	}])
	
	
db.users.insertOne( 
	{ 
		name: "Kapil",
		age: 43,
		marks: [194,78,76,67,57],
		hobbies: ["Reading", "Movies", "Chess"],
		contact: { phone: "1234567890", email: "kapil@gmail.com", facebook: "kapil.sharma.11000" },
		address: {city: "Hyderabad", state: "Telangana"}
	},
	{
		w: "majority", 
		wtimeout: 100
	}
)


// Ordered Inserts

db.budget.insertMany([
{_id: 1, budget: 20000, expenditure: 25000}, 
{_id: 2, budget: 22000, expenditure: 26000}, 
{_id: 3, budget: 35000, expenditure: 30000}, 
{_id: 4, budget: 43000, expenditure: 45000}, 
{_id: 5, budget: 28000, expenditure: 13000}
])

db.budget.insertMany([
{_id: 6, budget: 15000, expenditure: 8000}, 
{_id: 2, budget: 24000, expenditure: 15000}, 
{_id: 7, budget: 22000, expenditure: 22000}, 
{_id: 8, budget: 34000, expenditure: 35000}, 
{_id: 9, budget: 40000, expenditure: 41000}
])

db.budget.insertMany([
{_id: 6, budget: 40000, expenditure: 15000}, 
{_id: 2, budget: 30000, expenditure: 30000}, 
{_id: 7, budget: 30000, expenditure: 35000}, 
{_id: 8, budget: 60000, expenditure: 65000}, 
{_id: 9, budget: 14000, expenditure: 15000}
], {ordered: false})