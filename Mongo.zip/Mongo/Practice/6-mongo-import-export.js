~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      JSON Import & Export
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Note: Run the below commands from the /bin folder of Mongo installation location.

--import
mongoimport  --db <database-name> --collection <collection-name>  --file <json-file-name> --jsonArray
mongoimport  --db <database-name> --collection <collection-name>  --file <json-file-name> --jsonArray --drop

example:
mongoimport --db train --collection users --file "F:\YKR\MongoDB\Data\users.json" --jsonArray

--export
mongoexport --db <database-name> --collection <collection-name>  --out <json-file-name> 

example:
mongoexport --db train --collection users --out "F:\YKR\MongoDB\Data\users_exp.json"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      CSV Import & Export
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Note: Run the below commands from the /bin folder of Mongo installation location.

To import:  
-------------
mongoimport --db <db-name> --collection <collection-name> --type csv --headerline --file <csv-file>
mongoimport -d <db-name> -c <collection-name> --type csv --headerline --file <csv-file>

To Export:   
-------------
mongoexport --db <db-name> --collection <collection-name> --type csv --fields <fileds-list> --out <csv-file>
mongoexport -d <db-name> -c <collection-name> --type csv --fields <fileds-list> --out <csv-file>

Examples:
-------------
mongoimport --db mydb -c addresses --type csv --headerline --file "D:\MongoDB\data\addresses.csv"
mongoexport --db mydb --collection addresses --type csv --fields Name,City,State --out "D:\MongoDB\data\addresses_exp_2.csv"

================
> mongoimport --host <host_name> --username <user_name> --password <password> --db <database_name> --collection <collection_name> --file <input_file>

> mongoexport --host <host_name> --username <user_name> --password <password> --db <database_name> --collection <collection_name> --out <output_file>

--host is an optional parameter that specifies the remote server Mongo database instance
--username and --password are the optional parameters that specify the authentication details of a user
--db specifies the database name
--collection specifies the collection name
--file specifies the path of the input file. If this is not specified, the standard input (i.e. stdin) is used