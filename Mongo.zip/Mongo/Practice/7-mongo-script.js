
c:\> mongo localhost:27017/demo "F:\YKR\MongoDB\Practice\myjstest.js"

c:\> mongo test --eval "printjson(db.getCollectionNames())"	

from with-in shell, you can load script files like this:

	load("scripts/myjstest.js")
	load("/data/db/scripts/myjstest.js")
	
	
show dbs, show databases	
db.adminCommand('listDatabases')

use <db>
db = db.getSiblingDB('<db>')

show collections
db.getCollectionNames()

show users
db.getUsers()

show roles
db.getRoles({showBuiltinRoles: true})

show log <logname>
db.adminCommand({ 'getLog' : '<logname>' })

show logs
db.adminCommand({ 'getLog' : '*' })

it
cursor = db.collection.find()
if ( cursor.hasNext() ){
   cursor.next();
}	
	
	
	
