cursor = db.users2.find();
while ( cursor.hasNext() ) {
   printjson( cursor.next() );
}